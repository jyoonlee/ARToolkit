
#ifndef __COLOR_DETECTION_H__
#define __COLOR_DETECTION_H__

void InitImageProcessing( int width, int height );
void ClearImageProcessing(void);
void DetectColor( unsigned char *image, double *x, double *y );

#endif